package menu;

import java.util.Scanner;

public class Menu {
    public void menu(){
        Scanner sc = new Scanner(System.in);

        
    }
}
