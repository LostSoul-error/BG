import menu.Menu;

public class main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.menu();
    }
}
